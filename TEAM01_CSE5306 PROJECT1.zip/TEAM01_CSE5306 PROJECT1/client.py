import routeguide_pb2_grpc
import routeguide_pb2
import grpc
from PIL import Image
import io

def run():
    with grpc.insecure_channel('localhost:50051') as channel:
        stub=routeguide_pb2_grpc.RouteGuideStub (channel)
        picture= input("what animal picture you want to search for?")
        reply = stub.ImageSearch(routeguide_pb2.Client(keyword=picture))
        with open(f'{picture}.jpg', 'wb') as f:
            #saves image
            print(f.write(reply.image))

        img = Image.open(io.BytesIO(reply.image))
        img.show()

if __name__ == '__main__':
    run()
