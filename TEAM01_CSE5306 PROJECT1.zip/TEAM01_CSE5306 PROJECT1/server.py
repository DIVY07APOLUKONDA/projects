from concurrent import futures
import grpc
import routeguide_pb2
import routeguide_pb2_grpc

import os
import random

#finding the absolute path in the Database
Database = os.path.abspath("DB/images")
print("[CONNECTED]")



class RouteGuideServicer(routeguide_pb2_grpc.RouteGuideServicer):
    def ImageSearch(self, request, context):
        
        keyword = request.keyword

        object_directory = os.path.join(Database, keyword)
        if os.path.exists(object_directory) and os.path.isdir(object_directory):
            # List jpg images from sub-directory
            listfiles = os.listdir(object_directory)
            files = [f for f in listfiles
                     if os.path.isfile(os.path.join(object_directory, f)) 
                     and f.endswith(".jpg")]
            
            if files:
                # Randomly select an image
                random_image = random.choice(files)
                with open(os.path.join(object_directory, random_image), 'rb') as image_file:

                    image_server = image_file.read()
                    return routeguide_pb2.Server(image=image_server)


        return super().ImageSearch(request, context)
    
def serve ():
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        routeguide_pb2_grpc.add_RouteGuideServicer_to_server(RouteGuideServicer(), server)
        server.add_insecure_port("localhost:50051")
        server.start()
        server.wait_for_termination()

if __name__ == '__main__':
        serve()