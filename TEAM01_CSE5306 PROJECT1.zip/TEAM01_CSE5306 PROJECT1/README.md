
# CSE5306 - PROJECT 01

A simple image search engine using gRPC.

All members of the team contributed equally on this project.

# How to run
- install grpcio with the CMD ('pip install grpcio')
- install protobuf
- in the command prompt type 'py server.py' to connect the server (for windows)
- open up a new terminal and type 'py client.py' (for windows)
- the client side will ask for a 'keyword' by which the server will search in its database
- we only have five object class - dog, cat, tiger, lion, and bird. Client can look for images for these object classes only
- after giving the keyword, the server will return the image of the object if it exists in the database
-image will open up in the default photo viewer

# Errors
         1. Our code can not handle errors when an image do not exit in the database.
         2. We were successful in containering the server code (screenshots attached in the report). But for the client it was not working.
	     3. When server was running on docker the client was not working. So, we included the code without dockerizing.

# References
1.	https://docs.docker.com/language/python/containerize/
2.	https://gist.github.com/adrianratnapala/1535780
3.	https://www.youtube.com/watch?v=WB37L7PjI5k&t=923s&ab_channel=MissCoding
4.  https://www.askpython.com/python/examples/display-images-using-python
5.  https://stackoverflow.com/questions/32908639/open-pil-image-from-byte-file

