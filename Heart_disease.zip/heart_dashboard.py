import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier

# Load dataset
@st.cache_data
def load_data():
    df = pd.read_csv("heart.csv")
    return df

df = load_data()

# Encode categorical variables
def preprocess_data(df):
    df = pd.get_dummies(df, columns=['Sex', 'ChestPainType', 'RestingECG', 'ExerciseAngina', 'ST_Slope'], drop_first=True)
    X = df.drop(columns=['HeartDisease'])
    y = df['HeartDisease']
    return X, y

# Sidebar
st.sidebar.title("Model Selection & Configuration")
model_choice = st.sidebar.selectbox("Select Model", ["Logistic Regression", "KNN", "Random Forest", "SVM", "XGBoost"])

st.title("❤️ Heart Disease Prediction Dashboard")

# Show data
if st.checkbox("Show Dataset"):
    st.write(df)

# Visuals
if st.checkbox("Show Correlation Heatmap"):
    st.subheader("Correlation Heatmap")
    
    # Only use numeric columns
    numeric_df = df.select_dtypes(include=[np.number])
    
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", ax=ax)
    st.pyplot(fig)


# Preprocessing
X, y = preprocess_data(df)
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Model training
def train_model(model_name):
    if model_name == "Logistic Regression":
        model = LogisticRegression(max_iter=200)
    elif model_name == "KNN":
        model = KNeighborsClassifier(n_neighbors=5)
    elif model_name == "Random Forest":
        model = RandomForestClassifier(n_estimators=100)
    elif model_name == "SVM":
        model = SVC(probability=True)
    elif model_name == "XGBoost":
        model = XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    else:
        return None

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    return model, acc, cm

model, accuracy, cm = train_model(model_choice)

st.success(f"{model_choice} Accuracy: {accuracy:.2f}")

if st.checkbox("Show Confusion Matrix"):
    st.write(cm)

st.subheader("🔍 Predict Heart Disease")
user_input = []

for feature in X.columns:
    if feature in df.columns:
        val = st.number_input(f"{feature}", value=float(df[feature].mean()))
    else:
        # For one-hot encoded/dummy columns not in original df
        val = st.number_input(f"{feature}", value=0.0, min_value=0.0, max_value=1.0)
    user_input.append(val)
