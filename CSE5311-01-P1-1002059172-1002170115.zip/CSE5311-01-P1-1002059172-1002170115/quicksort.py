import time

#taking elements from list into 2d list
def txtToArr(textFile,arr):
    with open(textFile) as f:
        for line in f:
            array = [number.strip() for number in line.split(" ")]
            arr.append(array)

#casting the elements of list into int from string
def castIntoInt(a,x):
   x = [list(map(int, i)) for i in a]
   return x

#add one new column
def extendCol(a):
    for column in a:
        column.extend([0])

#finding sum of the rows
def summation(a,row):
    for i in range (row):
        num=0
        for j in range (4):
            num = num+a[i][j]
        a[i][3]=num


def quicksort(arr,start,end):
    if start < end:
        pivot= Partition (arr, start,end)
        quicksort(arr, start,pivot-1)
        quicksort(arr,pivot+1,end)

def Partition(A,start,end):
    pivot = A[end][3]
    indexPartition = start

    for j in range(start,end):
        if A[j][3] <= pivot:

            temp = A[indexPartition]
            A[indexPartition] = A[j]
            A[j] = temp
            indexPartition = indexPartition + 1

    temp = A[indexPartition]
    A[indexPartition] = A[end]
    A[end] = temp

    return indexPartition

#generating output file
def output (array, textFile, row):
    f = open(textFile, "w")
    for i in range(row):
        f.write(" ".join(map(str, new_array[i])) + "\n")

#finding the running time
def execution_time(start,end,textFile):
    execution_time = end - start
    f = open(textFile, "a")
    # f.write("something")
    f.write(str(execution_time))

arr=[]
new_array=[]

#for 20 inputs
txtToArr('arr20.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,20)

st20=time.perf_counter()
quicksort(new_array,0,19)
end20=time.perf_counter()

output(new_array, "arrQK_O_20.txt", 20)
execution_time(st20,end20,"arrQK_O_20.txt")

#for 100 inputs
txtToArr('arr100.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,100)

st100=time.perf_counter()
quicksort(new_array,0,99)
end100=time.perf_counter()

output(new_array, "arrQK_O_100.txt", 100)
execution_time(st100,end100,"arrQK_O_100.txt")

#for 2000 inputs
txtToArr('arr2000.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,2000)

st2000=time.perf_counter()
quicksort(new_array,0,1999)
end2000=time.perf_counter()

output(new_array, "arrQK_O_2000.txt", 2000)
execution_time(st2000,end2000,"arrQK_O_2000.txt")

#for 6000 inputs
txtToArr('arr6000.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,6000)

st6000=time.perf_counter()
quicksort(new_array,0,5999)
end6000=time.perf_counter()

output(new_array, "arrQK_O_6000.txt", 6000)
execution_time(st6000,end6000,"arrQK_O_6000.txt")

