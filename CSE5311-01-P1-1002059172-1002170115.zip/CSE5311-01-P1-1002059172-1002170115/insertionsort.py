import random
import time


#generating random numbers and putting them into input file
def generate (textFile, row):
    f = open(textFile, 'w')
    for i in range(row):
                numbers = random.sample(range(0, 99), 3)

                f.write(" ".join(map(str,numbers)) + "\n")
    f.close()

#taking elements from list into 2d list
def txtToArr(textFile,arr):
    with open(textFile) as f:
        for line in f:
            array = [number.strip() for number in line.split(" ")]
            arr.append(array)

#casting the elements of list into int from string
def castIntoInt(a,x):
   x = [list(map(int, i)) for i in a]
   return x

#add one new column
def extendCol(a):
    for column in a:
        column.extend([0])

#finding sum of the rows
def summation(a,row):
    for i in range (row):
        num=0
        for j in range (4):
            num = num+a[i][j]
        a[i][3]=num


def insertion_sort(a, row):
    j=1
    for j in range(row):
        key = a[j][3]
        temp=a[j]
        i = j-1
        while i > -1 and a[i][3] > key:

            a[i + 1] = a[i]
            i = i-1

        a[i+1]=temp

#generating output file
def output (array, textFile, row):
    f = open(textFile, "w")
    for i in range(row):
        f.write(" ".join(map(str, new_array[i])) + "\n")

#finding the running time
def execution_time(start,end,textFile):
    execution_time = end - start
    f = open(textFile, "a")
    # f.write("something")
    f.write(str(execution_time))

arr=[]
new_array=[]

#for 20 inputs
generate ("arr20.txt", 20)
txtToArr('arr20.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,20)

st20=time.perf_counter()
insertion_sort(new_array, 20)
end20=time.perf_counter()


output(new_array, "arrIS_O_20.txt", 20)
execution_time(st20,end20,"arrIS_O_20.txt")

#for 100 input
generate ("arr100.txt", 100)
txtToArr('arr100.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,100)

st100=time.perf_counter()
insertion_sort(new_array, 100)
end100=time.perf_counter()

output(new_array, "arrIS_O_100.txt", 100)
execution_time(st100,end100, "arrIS_O_100.txt")

#for 2000 input
generate ("arr2000.txt", 2000)
txtToArr('arr2000.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,2000)

st2000=time.perf_counter()
insertion_sort(new_array, 2000)
end2000=time.perf_counter()

output(new_array, "arrIS_O_2000.txt", 2000)
execution_time(st2000,end2000, "arrIS_O_2000.txt")

#for 6000 input
generate ("arr6000.txt", 6000)
txtToArr('arr6000.txt', arr)
new_array = castIntoInt(arr,new_array)
extendCol(new_array)
summation(new_array,6000)

st6000=time.perf_counter()
insertion_sort(new_array, 6000)
end6000=time.perf_counter()

output(new_array, "arrIS_O_6000.txt", 6000)
execution_time(st6000,end6000, "arrIS_O_6000.txt")



