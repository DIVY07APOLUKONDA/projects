# CSE5311 - PROJECT 01

This project includes three sorting algorithms - insetion sort, mergesort, and quicksort. The goal of this project is to see how the input size affects the time complexity of each algoritms.

# Built With

This project was build using python

# How to run

1. IDE needs to have python extension installed
2. Run the insertionsort.py file first to generate input files. These input files will also be used by mergesort and quicksort.

# Contact

Tabassum Faruk - 1002059172
txf9172@mavs.uta.edu

Divya Polukonda - 1002170115
dxp0115@mavs.uta.edu
